#include <Windows.h>

int main(int argc, char* argv[])
{
	MessageBoxW(NULL, L"This is a normal message box", L"Info", MB_OK);
	return 0;
}